import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router";
import App from "./App.jsx";
import { VisitProvider } from "./context/VisitContext.jsx";
import "./index.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <VisitProvider>
        <App />
      </VisitProvider>
    </BrowserRouter>
  </StrictMode>
);